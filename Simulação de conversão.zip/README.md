
# Conversor de Partitura ↔ Tablatura 🎵

Este projeto é um layout inicial para um site que converte partitura em tablatura e vice-versa. Criado com HTML5 e TailwindCSS via CDN.

## 🔧 Funcionalidades

- Upload de arquivos
- Seleção de tipo de conversão
- Prévia e botão para baixar resultado

## 🚀 Como usar

1. Clone ou baixe este repositório.
2. Abra o arquivo `index.html` em qualquer navegador.
3. Edite e personalize conforme suas necessidades.

## 📡 Publicar com GitHub Pages

1. Vá em **Configurações > Pages**
2. Selecione a branch principal (geralmente `main`) e a pasta `/root`
3. O site ficará disponível em: `https://seu-usuario.github.io/nome-do-repo`

## 📄 Licença

Este projeto é livre para uso educacional e pessoal.
